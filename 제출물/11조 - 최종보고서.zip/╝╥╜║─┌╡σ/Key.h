#pragma once
#define UP 72
#define DOWN 80
#define LEFT 75
#define RIGHT 77
#define ENTER 13
#define ESC 27
#define SPACE_BAR 32
#define DOWN_ 145
#define RIGHT_ 116
#define UP_ 141
#define LEFT_ 115
#define BACKSPACE 8
#define ONE 49
#define TWO 50
#define THREE 51
#define FOUR 52
#define FIVE 53
#define SIX 54
#define SEVEN 55

/*�۵�����Ȯ�� ����*/
#define NOT_WORK 0
#define WORK 0