#pragma once
#include<stdio.h>
#include<windows.h>
#include<time.h>
#include<stdlib.h>
#include<conio.h>
#include<string.h>
#define C_WHITE 15
#define C_YELLOW 14
#define C_PINK 13
#define C_RED 12
#define C_SKYBLUE 11
#define C_GREEN 10
#define C_BLUE 9
#define C_GRAY 8
#define C_WHITE_ 7
#define C_YELLOW_ 6
#define C_PURPLE 5
#define C_BROWN 4
#define C_RED_ 4
#define C_SKYBLUE_ 3
#define C_GREEN_ 2
#define C_BLUE_ 1
#define C_BLACK 0
#define E_NON 15
#define E_ICE 11
#define E_FLAME 12
#define E_ELECT 6

//���� �ٲٴ� �Լ�
void setcolor(int color, int bgcolor);