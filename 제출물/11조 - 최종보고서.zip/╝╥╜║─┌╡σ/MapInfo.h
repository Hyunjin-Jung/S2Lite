#pragma once
extern int NormalMapInfo[39][123];
extern int TownInfo[39][123];
extern int ShowDie[50][160];